# Inventory-Example
Project was made as a challenge in one hour so it probably isn't flawless, enjoy ;)
