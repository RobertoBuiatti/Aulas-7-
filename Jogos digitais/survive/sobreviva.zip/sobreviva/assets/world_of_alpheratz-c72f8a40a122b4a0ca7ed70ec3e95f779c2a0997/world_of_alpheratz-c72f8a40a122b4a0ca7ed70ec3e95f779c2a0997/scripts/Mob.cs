using Godot;

public partial class Mob : CharacterBody2D
{
    public virtual void Perish()
    {
        GD.PushWarning("Mob::Perish() is not implemented yet.");
    }
}
